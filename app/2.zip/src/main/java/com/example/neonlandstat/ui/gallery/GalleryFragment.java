package com.example.neonlandstat.ui.gallery;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import android.webkit.WebView;
import android.webkit.WebViewClient;


import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.neonlandstat.R;
import com.example.neonlandstat.databinding.FragmentGalleryBinding;

public class GalleryFragment extends Fragment {

    private FragmentGalleryBinding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

//Загружаем разметку из XML
        View v = inflater.inflate(R.layout.fragment_gallery, container, false);

//Находим WebView и загружаем что-нибудь
        WebView webView = (WebView) v.findViewById(R.id.webview);
        webView.loadUrl("https://neonlandstore.trademc.org/");
        webView.getSettings().setJavaScriptEnabled(true);

//Метод должен возвращать View
        return v;
    }
}