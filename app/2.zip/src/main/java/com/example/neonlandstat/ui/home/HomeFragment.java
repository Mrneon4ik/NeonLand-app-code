package com.example.neonlandstat.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.neonlandstat.R;
import com.example.neonlandstat.databinding.FragmentHomeBinding;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

//Загружаем разметку из XML
        View b = inflater.inflate(R.layout.fragment_home, container, false);

//Находим WebView и загружаем что-нибудь
        WebView twebView = (WebView) b.findViewById(R.id.vkweb);
        twebView.loadUrl("http://topsmax037.temp.swtest.ru/");
        //twebView.getSettings().setJavaScriptEnabled(true);

//Метод должен возвращать View
        return b;
    }
}